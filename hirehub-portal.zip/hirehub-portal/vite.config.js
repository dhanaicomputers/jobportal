import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: "base" must match your GitHub repository name exactly.
export default defineConfig({
  plugins: [react()],
  base: "/hirehub-portal/",
});
