# HireHub – Job Portal (React SPA)

A single-page job portal built with **React.js** and **Vite**. Users can browse openings, filter them, save favourites and apply for a job.

## Live Demo
https://YOUR-USERNAME.github.io/hirehub-portal/

## Features
- Search jobs by title, company or skill
- Filter by location and job type
- Save / unsave jobs (Saved page with live counter)
- Job details view with an application form
- Fully responsive (mobile, tablet, desktop)

## React Concepts Used
- Functional components (`Navbar`, `JobCard`, `JobDetails`, `App`)
- Props for passing data and callbacks between components
- `useState` for search, filters, saved jobs, form data and the current view
- View toggling (Browse / Saved / Details) without page reload
- Conditional rendering and list rendering with `map()` and `filter()`

## Technologies
React 18, Vite, JavaScript (ES6), CSS3

## How to Run
```bash
npm install
npm run dev
```

## Deploy to GitHub Pages
```bash
npm run deploy
```
(Make sure `base` in `vite.config.js` matches your repository name.)

## Author
YOUR NAME – SE INFT, Roll No. XX
