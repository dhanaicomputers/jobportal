import { useState } from "react";
import "./App.css";

/* ================= JOB DATA ================= */

const jobsData = [
  {
    id: 1,
    title: "React Developer",
    company: "PixelForge Labs",
    location: "Mumbai",
    type: "Full Time",
    salary: "₹7 - 12 LPA",
    skills: ["React", "JavaScript", "REST APIs"],
    description:
      "Build fast, accessible user interfaces for our SaaS dashboard and work closely with designers and backend engineers.",
  },
  {
    id: 2,
    title: "Backend Engineer (Node.js)",
    company: "CloudNest Systems",
    location: "Pune",
    type: "Full Time",
    salary: "₹8 - 14 LPA",
    skills: ["Node.js", "MongoDB", "Express"],
    description:
      "Design and maintain scalable APIs and microservices that power thousands of daily users.",
  },
  {
    id: 3,
    title: "Data Analyst",
    company: "InsightWorks",
    location: "Bangalore",
    type: "Full Time",
    salary: "₹6 - 10 LPA",
    skills: ["SQL", "Python", "Power BI"],
    description:
      "Turn raw business data into clear reports and dashboards that help leadership make decisions.",
  },
  {
    id: 4,
    title: "Graphic & UI Designer",
    company: "Studio Mango",
    location: "Mumbai",
    type: "Part Time",
    salary: "₹3 - 5 LPA",
    skills: ["Figma", "Photoshop", "Branding"],
    description:
      "Create social media creatives, landing page designs and brand assets for startup clients.",
  },
  {
    id: 5,
    title: "Software Testing Intern",
    company: "QualityFirst Tech",
    location: "Hyderabad",
    type: "Internship",
    salary: "₹12,000 / month",
    skills: ["Manual Testing", "Selenium", "Bug Reports"],
    description:
      "Learn real-world QA practices, write test cases and help the team find bugs before release.",
  },
  {
    id: 6,
    title: "Cyber Security Associate",
    company: "ShieldSecure",
    location: "Delhi",
    type: "Full Time",
    salary: "₹9 - 15 LPA",
    skills: ["Networking", "Linux", "Security Tools"],
    description:
      "Monitor systems for threats, run vulnerability scans and help respond to security incidents.",
  },
  {
    id: 7,
    title: "Python Intern",
    company: "CodeSprout",
    location: "Pune",
    type: "Internship",
    salary: "₹10,000 / month",
    skills: ["Python", "Git", "Problem Solving"],
    description:
      "Work on small automation scripts and internal tools under the guidance of senior developers.",
  },
  {
    id: 8,
    title: "Full Stack Developer",
    company: "BrightByte Solutions",
    location: "Remote",
    type: "Full Time",
    salary: "₹10 - 18 LPA",
    skills: ["React", "Node.js", "MySQL"],
    description:
      "Own features end to end, from database design to polished front-end screens, in a remote-first team.",
  },
];

const locations = ["All", ...new Set(jobsData.map((j) => j.location))];
const types = ["All", "Full Time", "Part Time", "Internship"];

/* ================= SMALL COMPONENTS (props) ================= */

function Navbar({ view, setView, savedCount }) {
  return (
    <header className="topbar">
      <div className="brand" onClick={() => setView("home")}>
        Hire<span>Hub</span>
      </div>
      <nav className="menu">
        <button
          className={view === "home" ? "menu-btn active" : "menu-btn"}
          onClick={() => setView("home")}
        >
          Browse Jobs
        </button>
        <button
          className={view === "saved" ? "menu-btn active" : "menu-btn"}
          onClick={() => setView("saved")}
        >
          Saved
          <span className="count">{savedCount}</span>
        </button>
      </nav>
    </header>
  );
}

function JobCard({ job, isSaved, onSave, onOpen }) {
  return (
    <article className="job-card">
      <div className="job-top">
        <div className="avatar">{job.company.charAt(0)}</div>
        <div>
          <h3>{job.title}</h3>
          <p className="company">{job.company}</p>
        </div>
      </div>

      <div className="meta">
        <span>📍 {job.location}</span>
        <span>🕒 {job.type}</span>
      </div>
      <p className="salary">{job.salary}</p>

      <div className="chips">
        {job.skills.map((s) => (
          <span key={s} className="chip">
            {s}
          </span>
        ))}
      </div>

      <div className="card-actions">
        <button className="btn primary" onClick={() => onOpen(job)}>
          View Details
        </button>
        <button
          className={isSaved ? "btn ghost saved" : "btn ghost"}
          onClick={() => onSave(job.id)}
        >
          {isSaved ? "★ Saved" : "☆ Save"}
        </button>
      </div>
    </article>
  );
}

function JobDetails({ job, isSaved, onSave, onBack }) {
  const [form, setForm] = useState({ name: "", email: "" });
  const [applied, setApplied] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleApply = (e) => {
    e.preventDefault();
    setApplied(true);
  };

  return (
    <section className="details">
      <button className="back" onClick={onBack}>
        ← Back to jobs
      </button>

      <div className="details-grid">
        <div className="details-main">
          <div className="avatar big">{job.company.charAt(0)}</div>
          <h2>{job.title}</h2>
          <p className="company">{job.company}</p>

          <div className="meta">
            <span>📍 {job.location}</span>
            <span>🕒 {job.type}</span>
            <span>💰 {job.salary}</span>
          </div>

          <h4>About the role</h4>
          <p>{job.description}</p>

          <h4>Skills required</h4>
          <div className="chips">
            {job.skills.map((s) => (
              <span key={s} className="chip">
                {s}
              </span>
            ))}
          </div>

          <button
            className={isSaved ? "btn ghost saved" : "btn ghost"}
            onClick={() => onSave(job.id)}
          >
            {isSaved ? "★ Saved" : "☆ Save this job"}
          </button>
        </div>

        <aside className="apply-box">
          <h4>Apply for this job</h4>
          {applied ? (
            <p className="success">
              ✅ Thanks {form.name}! Your application for{" "}
              <b>{job.title}</b> has been submitted.
            </p>
          ) : (
            <form onSubmit={handleApply}>
              <input
                name="name"
                placeholder="Full name"
                value={form.name}
                onChange={handleChange}
                required
              />
              <input
                name="email"
                type="email"
                placeholder="Email address"
                value={form.email}
                onChange={handleChange}
                required
              />
              <button className="btn primary full">Submit Application</button>
            </form>
          )}
        </aside>
      </div>
    </section>
  );
}

/* ================= MAIN APP ================= */

export default function App() {
  const [view, setView] = useState("home"); // home | saved | details
  const [selectedJob, setSelectedJob] = useState(null);
  const [saved, setSaved] = useState([]); // list of saved job ids
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState("All");
  const [type, setType] = useState("All");

  const toggleSave = (id) =>
    setSaved((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );

  const openJob = (job) => {
    setSelectedJob(job);
    setView("details");
    window.scrollTo(0, 0);
  };

  const filtered = jobsData.filter((j) => {
    const q = search.toLowerCase();
    const matchSearch =
      j.title.toLowerCase().includes(q) ||
      j.company.toLowerCase().includes(q) ||
      j.skills.join(" ").toLowerCase().includes(q);
    const matchLoc = location === "All" || j.location === location;
    const matchType = type === "All" || j.type === type;
    return matchSearch && matchLoc && matchType;
  });

  const savedJobs = jobsData.filter((j) => saved.includes(j.id));

  const clearFilters = () => {
    setSearch("");
    setLocation("All");
    setType("All");
  };

  return (
    <div className="app">
      <Navbar view={view} setView={setView} savedCount={saved.length} />

      {view === "home" && (
        <>
          <section className="hero">
            <h1>
              Your next career move <br />
              starts <span>here.</span>
            </h1>
            <p>Search openings by role, company or skill.</p>
          </section>

          <main className="layout">
            <aside className="filters">
              <h4>Filters</h4>

              <label>Search</label>
              <input
                placeholder="Title, company or skill"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

              <label>Location</label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              >
                {locations.map((l) => (
                  <option key={l}>{l}</option>
                ))}
              </select>

              <label>Job type</label>
              <div className="pill-row">
                {types.map((t) => (
                  <button
                    key={t}
                    className={type === t ? "pill on" : "pill"}
                    onClick={() => setType(t)}
                  >
                    {t}
                  </button>
                ))}
              </div>

              <button className="btn ghost full" onClick={clearFilters}>
                Reset filters
              </button>
            </aside>

            <section className="results">
              <div className="results-head">
                <h2>Open positions</h2>
                <span>{filtered.length} found</span>
              </div>

              {filtered.length === 0 ? (
                <p className="empty">No jobs match your filters. Try again.</p>
              ) : (
                <div className="grid">
                  {filtered.map((job) => (
                    <JobCard
                      key={job.id}
                      job={job}
                      isSaved={saved.includes(job.id)}
                      onSave={toggleSave}
                      onOpen={openJob}
                    />
                  ))}
                </div>
              )}
            </section>
          </main>
        </>
      )}

      {view === "saved" && (
        <main className="page">
          <div className="results-head">
            <h2>Saved jobs</h2>
            <span>{savedJobs.length} saved</span>
          </div>
          {savedJobs.length === 0 ? (
            <p className="empty">
              You haven't saved any jobs yet. Tap ☆ Save on a job to keep it
              here.
            </p>
          ) : (
            <div className="grid">
              {savedJobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  isSaved
                  onSave={toggleSave}
                  onOpen={openJob}
                />
              ))}
            </div>
          )}
        </main>
      )}

      {view === "details" && selectedJob && (
        <main className="page">
          <JobDetails
            job={selectedJob}
            isSaved={saved.includes(selectedJob.id)}
            onSave={toggleSave}
            onBack={() => setView("home")}
          />
        </main>
      )}

      <footer className="footer">© 2026 HireHub · Built with React</footer>
    </div>
  );
}
